import React from 'react';
import { Card } from '@/lib/gameEngine';
import { PlayingCard } from './PlayingCard';
import { cn } from '@/lib/utils';

interface CardHandProps {
  cards: Card[];
  onPlayCard: (index: number) => void;
  disabled: boolean;
  className?: string;
}

export function CardHand({ cards, onPlayCard, disabled, className }: CardHandProps) {
  const total = cards.length;
  
  return (
    <div className={cn("flex justify-center items-end h-32 sm:h-40 relative", className)}>
      <div className="flex relative">
        {cards.map((card, idx) => {
          // Calculate fan spread
          const spreadAngle = Math.min(15, total * 3);
          const angleStep = total > 1 ? (spreadAngle * 2) / (total - 1) : 0;
          const angle = -spreadAngle + angleStep * idx;
          const yOffset = Math.abs(angle) * 0.8;
          
          return (
            <div
              key={card.id}
              className="relative transition-all duration-300 origin-bottom"
              style={{
                transform: `rotate(${angle}deg) translateY(${yOffset}px)`,
                zIndex: idx,
                marginLeft: idx > 0 ? '-24px' : '0',
              }}
            >
              <PlayingCard 
                card={card} 
                onClick={() => onPlayCard(idx)}
                disabled={disabled}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}
