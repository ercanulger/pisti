import { useEffect, useState } from 'react';
import { UserProfile } from '@/lib/firestore';

// In a real app, you might listen to realtime changes on auth context, 
// but we just export the hooks directly since we already have useAuth in contexts
export { useAuth } from '@/contexts/AuthContext';
export { useLeaderboard, usePublicProfile } from './useData';
