import { doc, getDoc, setDoc, updateDoc, collection, query, where, getDocs, orderBy, limit, Timestamp } from 'firebase/firestore';
import { db } from './firebase';

export interface UserProfile {
  uid: string;
  email: string;
  nickname: string;
  photoBase64: string | null;
  isAdmin: boolean;
  isEmailVerified: boolean;
  trophies: number;
  coins: number;
  gamesPlayed: number;
  gamesWon: number;
  createdAt: Timestamp | Date;
  ownedFrames: string[];
  ownedTables: string[];
  activeFrame: string | null;
  activeTable: string | null;
}

export interface GameHistory {
  id?: string;
  uid: string;
  result: 'win' | 'loss' | 'draw';
  score: number;
  pistiCount: number;
  coinsEarned: number;
  trophiesEarned: number;
  playedAt: Timestamp | Date;
}

export const firestoreHelpers = {
  async getUserProfile(uid: string): Promise<UserProfile | null> {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    }
    return null;
  },

  async createUserProfile(uid: string, data: Partial<UserProfile>) {
    const docRef = doc(db, 'users', uid);
    const defaultProfile: Partial<UserProfile> = {
      uid,
      photoBase64: null,
      isAdmin: data.email === 'ercanulger@pistigame.com',
      trophies: 0,
      coins: 500,
      gamesPlayed: 0,
      gamesWon: 0,
      createdAt: new Date(),
      ownedFrames: [],
      ownedTables: ['table_classic'],
      activeFrame: null,
      activeTable: 'table_classic',
      ...data
    };
    await setDoc(docRef, defaultProfile, { merge: true });
    return defaultProfile;
  },

  async updateUserProfile(uid: string, data: Partial<UserProfile>) {
    const docRef = doc(db, 'users', uid);
    await updateDoc(docRef, data);
  },

  async isNicknameTaken(nickname: string): Promise<boolean> {
    const q = query(collection(db, 'users'), where('nickname', '==', nickname));
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  },

  async getLeaderboard(limitCount: number = 100): Promise<UserProfile[]> {
    const q = query(collection(db, 'users'), orderBy('trophies', 'desc'), limit(limitCount));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => doc.data() as UserProfile);
  },

  async saveGameResult(history: GameHistory) {
    const newDocRef = doc(collection(db, 'gameHistory'));
    await setDoc(newDocRef, {
      ...history,
      playedAt: new Date()
    });
    
    // Update user profile stats
    const userRef = doc(db, 'users', history.uid);
    const userSnap = await getDoc(userRef);
    if (userSnap.exists()) {
      const userData = userSnap.data() as UserProfile;
      await updateDoc(userRef, {
        gamesPlayed: (userData.gamesPlayed || 0) + 1,
        gamesWon: (userData.gamesWon || 0) + (history.result === 'win' ? 1 : 0),
        coins: (userData.coins || 0) + history.coinsEarned,
        trophies: Math.max(0, (userData.trophies || 0) + history.trophiesEarned)
      });
    }
  },

  async getRecentGames(uid: string, limitCount: number = 5): Promise<GameHistory[]> {
    const q = query(collection(db, 'gameHistory'), where('uid', '==', uid), orderBy('playedAt', 'desc'), limit(limitCount));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as GameHistory));
  }
};
